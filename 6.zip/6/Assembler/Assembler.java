import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Assembler {
    private static final HashMap<String, Integer> SYMBOL_TABLE = new HashMap<>();
    private static final HashMap<String, String> COMP_A_TABLE = new HashMap<>();
    private static final HashMap<String, String> COMP_M_TABLE = new HashMap<>();
    private static final HashMap<String, String> DEST_TABLE = new HashMap<>();
    private static final HashMap<String, String> JUMP_TABLE = new HashMap<>();

    static {
        initializeTables();
    }

    public static void main(String[] args) {
        if (args.length == 0) {
            System.out.println("Usage: Assembler filename");
            return;
        }
        translateFile(args[0]);
    }

    private static void initializeTables() {
        // Initialize predefined symbols
        String[] predefinedSymbols = {
            "SP", "LCL", "ARG", "THIS", "THAT",
            "R0", "R1", "R2", "R3", "R4", "R5", "R6", "R7", "R8", "R9", "R10", "R11", "R12", "R13", "R14", "R15",
            "SCREEN", "KBD"
        };
        int[] addresses = {
            0, 1, 2, 3, 4, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16384, 24576
        };
        for (int i = 0; i < predefinedSymbols.length; i++) {
            SYMBOL_TABLE.put(predefinedSymbols[i], addresses[i]);
        }

        // Initialize computation tables
        String[] compAInstructions = {
            "0", "1", "-1", "D", "A", "!D", "!A", "-D", "-A", "D+1", "A+1", "D-1", "A-1", "D+A", "D-A", "A-D", "D&A", "D|A"
        };
        String[] compABits = {
            "101010", "111111", "111010", "001100", "110000", "001101", "110001", "001111", "110011",
            "011111", "110111", "001110", "110010", "000010", "010011", "000111", "000000", "010101"
        };
        for (int i = 0; i < compAInstructions.length; i++) {
            COMP_A_TABLE.put(compAInstructions[i], compABits[i]);
        }

        String[] compMInstructions = {
            "M", "!M", "-M", "M+1", "M-1", "D+M", "D-M", "M-D", "D&M", "D|M"
        };
        String[] compMBits = {
            "110000", "110001", "110011", "110111", "110010", "000010", "010011", "000111", "000000", "010101"
        };
        for (int i = 0; i < compMInstructions.length; i++) {
            COMP_M_TABLE.put(compMInstructions[i], compMBits[i]);
        }

        // Initialize destination table
        String[] destInstructions = {"", "M", "D", "MD", "A", "AM", "AD", "AMD"};
        String[] destBits = {"000", "001", "010", "011", "100", "101", "110", "111"};
        for (int i = 0; i < destInstructions.length; i++) {
            DEST_TABLE.put(destInstructions[i], destBits[i]);
        }

        // Initialize jump table
        String[] jumpInstructions = {"", "JGT", "JEQ", "JGE", "JLT", "JNE", "JLE", "JMP"};
        String[] jumpBits = {"000", "001", "010", "011", "100", "101", "110", "111"};
        for (int i = 0; i < jumpInstructions.length; i++) {
            JUMP_TABLE.put(jumpInstructions[i], jumpBits[i]);
        }
    }

    private static void translateFile(String filePath) {
        File inputFile = new File(filePath);

        if (!inputFile.getName().endsWith(".asm")) {
            throw new IllegalArgumentException("Wrong file format! Only .asm is accepted!");
        }

        try {
            Scanner scanner = new Scanner(inputFile);
            StringBuilder preprocessed = new StringBuilder();

            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                line = FileHelper.noSpaces(FileHelper.noComments(line));
                if (!line.isEmpty()) {
                    preprocessed.append(line).append("\n");
                }
            }

            String preprocessedCode = preprocessed.toString().trim();
            HashMap<String, Integer> labels = findLabels(preprocessedCode);
            String translatedCode = asmToHack(preprocessedCode, labels);

            String outputFileName = inputFile.getName().replace(".asm", ".hack");
            File outputFile = new File(inputFile.getParent(), outputFileName);

            try (PrintWriter writer = new PrintWriter(outputFile)) {
                writer.print(translatedCode);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    private static HashMap<String, Integer> findLabels(String code) {
        HashMap<String, Integer> labels = new HashMap<>();
        Scanner scanner = new Scanner(code);
        Pattern labelPattern = Pattern.compile("^\\([^0-9][0-9A-Za-z\\_\\:\\.\\$]+\\)$");
        int pc = 0;

        while (scanner.hasNextLine()) {
            String line = scanner.nextLine();
            Matcher matcher = labelPattern.matcher(line);
            if (matcher.find()) {
                String label = matcher.group().substring(1, matcher.group().length() - 1);
                labels.put(label, pc);
            } else {
                pc++;
            }
        }

        return labels;
    }

    private static String asmToHack(String code, HashMap<String, Integer> labels) {
        Scanner scanner = new Scanner(code);
        StringBuilder instructions = new StringBuilder();
        HashMap<String, Integer> variables = new HashMap<>();
        int startAddress = 16;

        while (scanner.hasNextLine()) {
            String line = scanner.nextLine();

            if (line.startsWith("@")) {
                instructions.append(handleAInstruction(line.substring(1), labels, variables, startAddress)).append("\n");
            } else if (line.startsWith("(")) {
                continue;
            } else {
                instructions.append(handleCInstruction(line)).append("\n");
            }
        }

        return instructions.toString();
    }

    private static String handleAInstruction(String symbol, HashMap<String, Integer> labels, HashMap<String, Integer> variables, int startAddress) {
        int address;

        if (labels.containsKey(symbol)) {
            address = labels.get(symbol);
        } else if (symbol.matches("\\d+")) {
            address = Integer.parseInt(symbol);
        } else {
            if (!variables.containsKey(symbol)) {
                int nextAddress = startAddress + variables.size();
                if (nextAddress >= 16384) {
                    throw new IllegalStateException("Out of memory! Too many user-defined symbols!");
                }
                variables.put(symbol, nextAddress);
            }
            address = variables.get(symbol);
        }

        return "0" + String.format("%15s", Integer.toBinaryString(address)).replace(' ', '0');
    }

    private static String handleCInstruction(String line) {
        String dest = "", comp = "", jump = "";
        int equalIndex = line.indexOf('=');
        int semicolonIndex = line.indexOf(';');

        if (equalIndex != -1) {
            dest = line.substring(0, equalIndex);
            comp = semicolonIndex != -1 ? line.substring(equalIndex + 1, semicolonIndex) : line.substring(equalIndex + 1);
        } else {
            comp = semicolonIndex != -1 ? line.substring(0, semicolonIndex) : line;
        }

        if (semicolonIndex != -1) {
            jump = line.substring(semicolonIndex + 1);
        }

        String a = COMP_A_TABLE.containsKey(comp) ? "0" : "1";
        String compBits = a.equals("0") ? COMP_A_TABLE.get(comp) : COMP_M_TABLE.get(comp);

        return "111" + a + compBits + DEST_TABLE.getOrDefault(dest, "000") + JUMP_TABLE.getOrDefault(jump, "000");
    }
}